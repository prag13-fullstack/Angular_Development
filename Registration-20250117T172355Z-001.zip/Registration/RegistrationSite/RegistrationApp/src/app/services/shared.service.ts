import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Registration } from '../models/user-model';

@Injectable({
  providedIn: 'root'
})

export class SharedService {
  private apiUrl = 'https://codingexercise.speakcore.com/api/registrations';

  constructor(private http: HttpClient) { }

  postRegistration(key: string, data: Registration): Observable<Registration> {
    const url = `${this.apiUrl}?key=${key}`;
    return this.http.post<Registration>(url, data).pipe(
      catchError(this.handleError)
    );
  }


  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred!';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}