  export interface Registration {
    firstName: string;
    lastName: string;
    state: string;
    email: string;
    subscribe: boolean;
  }