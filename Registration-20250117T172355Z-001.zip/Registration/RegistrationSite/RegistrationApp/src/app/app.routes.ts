import { Routes } from '@angular/router';
import { HomeComponent } from '../components/home/home.component';
import { RegistrationComponent } from '../components/registration/registration.component';
import { RegistrationSuccessComponent } from '../components/registration-success/registration-success.component';

export const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'registration', component: RegistrationComponent },
    { path: 'registration-success', component: RegistrationSuccessComponent }
  ];
