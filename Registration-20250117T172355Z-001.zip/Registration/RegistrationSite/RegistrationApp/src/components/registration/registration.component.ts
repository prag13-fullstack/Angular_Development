import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SubheaderComponent } from '../subheader/subheader.component';
import { StepperComponent } from '../stepper/stepper.component';
import { Registration } from '../../app/models/user-model';
import { SharedService } from '../../app/services/shared.service';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule,StepperComponent,SubheaderComponent,CommonModule,HttpClientModule],
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.scss',
  providers: [SharedService]
})
export class RegistrationComponent {
  registrationForm: FormGroup;
  states: string[] = [
    'Andhra Pradesh', ' Maharashtra', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa'
  ];

  constructor(private fb: FormBuilder , private router: Router,private registrationService: SharedService) {
    this.registrationForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      state: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      confirmEmail: ['', [Validators.required, Validators.email]],
      subscribeNewsletter: [false]
    }, { validators: this.emailMatchValidator });
  }

  emailMatchValidator(group: FormGroup) {
    const email = group.get('email')?.value;
    const confirmEmail = group.get('confirmEmail')?.value;
    return email === confirmEmail ? null : { emailMismatch: true };
  }

  isFieldInvalid(field: string): boolean {
    const control = this.registrationForm.get(field);
    return control!.invalid && (control!.dirty || control!.touched);
  }

  onSubmit() {
    if (this.registrationForm.valid) {
      const formData = this.registrationForm.value;
      this.registrationService.postRegistration(formData.email, formData).subscribe((response: Registration) => {
        console.log('Form Submitted', response);
        this.router.navigate(['/registration-success']);
      }, (error: any) => {
        console.error('Error submitting form', error);
      });
      this.router.navigate(['/registration-success']);
    } else {
      this.markAllFieldsAsTouched();
    }
   }

  markAllFieldsAsTouched() {
    Object.keys(this.registrationForm.controls).forEach(field => {
      const control = this.registrationForm.get(field);
      control?.markAsTouched({ onlySelf: true });
    });
  }
}