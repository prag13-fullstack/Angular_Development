import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { SubheaderComponent } from '../subheader/subheader.component';
import { StepperComponent } from '../stepper/stepper.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterModule ,SubheaderComponent ,StepperComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {

  constructor(private router: Router) {}

  navigateToRegistration() {
      this.router.navigate(['/registration']);
  }
}
