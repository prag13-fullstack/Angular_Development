import { Component } from '@angular/core';
import { SubheaderComponent } from '../subheader/subheader.component';
import { StepperComponent } from '../stepper/stepper.component';

@Component({
  selector: 'app-registration-success',
  standalone: true,
  imports: [SubheaderComponent,StepperComponent],
  templateUrl: './registration-success.component.html',
  styleUrl: './registration-success.component.scss'
})
export class RegistrationSuccessComponent {

}
